Address Book Symfony2 bundle project

Unzip the accompanying folder into the Symfony src folder.

	/project/src/Bee/AddbookBundle/etc...
	
Launch Address Book application in a browser, e.g.:

	http://localhost/project/web/app_dev.php/book
	
Landing page should be the Address Book, Book List page, see accompanying image

Use navigation links to explore the address book.