<?php

namespace Bee\AddbookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BeeAddbookBundle extends Bundle
{
}

// Debug method
function pr($arr) {echo '<pre />';print_r($arr);exit;}
